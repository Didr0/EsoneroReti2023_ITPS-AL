/*
 ============================================================================
 Name        : header.h
 Authors     : de Dato Domenico
 Authors     : Cassano Grazia
 Version     :
 Copyright   :
 Description : Calculator with UDP protocol client header file
 ============================================================================
 */

#ifndef HEADER_H_
#define HEADER_H_

#if defined WIN32
#include <winsock.h>
#include <windows.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#define NO_ERROR 0
#endif

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#define BUFFMAX 255


#endif /* HEADER_H_ */
