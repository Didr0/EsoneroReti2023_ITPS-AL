/*
 ============================================================================
 Name        : Calculator_TCP_client.c
 Authors     : de Dato Domenico
 Authors     : Cassano Grazia
 Version     :
 Copyright   : 
 Description : Calculator with TCP protocol client
 ============================================================================
 */

#include "header.h" // Include the header file, which presumably contains necessary declarations and macros

char* buffer; // Declare a global char pointer variable named 'buffer'

// Function to clear the console screen
void clearScreen(){
#ifdef _WIN32
	system("cls"); // Clear screen for Windows
#else
    system("clear"); // Clear screen for Linux/Unix
#endif
}

// Main function
int main() {
#ifdef _WIN32
	WSADATA wsaData; // Windows-specific structure to hold information about Winsock implementation
	SOCKET clientSocket; // Windows-specific socket type
#else
    int clientSocket; // Unix/Linux socket type
#endif

	struct sockaddr_in serverAddr; // Structure to hold server address information

#ifdef _WIN32
	// Initialize Winsock
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
		printf("Error during Winsock initialization.\n");
		return 1;
	}
#endif

	// Create a socket
	clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (clientSocket == -1) {
		printf("Error creating the socket.\n");
		return 1;
	}

	// Configure server address
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDR); // Set the server IP address
	serverAddr.sin_port = htons(PORT); // Set the server port

	// Connect to the server
	if (connect(clientSocket, (struct sockaddr*) &serverAddr,
			sizeof(serverAddr)) == -1) {
		printf("Error connecting to the server.\n");
		return 1;
	}

	// Main loop for sending/receiving data
	while (1) {
		char* choice = malloc(sizeof(char[BUFFER_SIZE])); // Allocate memory for user choice
		clearScreen(); // Clear the console screen

		buffer = malloc(sizeof(char[BUFFER_SIZE])); // Allocate memory for the buffer
		puts("Insert string with operation.");

		do{
			fgets(buffer, BUFFER_SIZE, stdin); // Read user input
		}while(buffer[0] == '\n'); // Continue until a non-empty input is provided
		buffer[strlen(buffer) - 1] = '\0'; // Remove newline character
		fflush(stdin);

		// Send the user input to the server
		send(clientSocket, buffer, strlen(buffer), 0);

        memset(buffer, '\0', BUFFER_SIZE); // Clear the buffer

		// Receive the result from the server
		recv(clientSocket, buffer, BUFFER_SIZE, 0);

		puts(buffer); // Print the result

		puts("Type \"=\" to exit the program or press any key to continue.");
		fgets(choice, BUFFER_SIZE, stdin); // Read user choice

		// Check if the user wants to exit
		if (choice[0] == '=' && strlen(choice) == 2) {
			clearScreen();
			puts("Program terminated successfully.");
			break; // Exit the loop and terminate the program
		}else
		{
			fflush(stdin);
		}
	}

#ifdef _WIN32
	closesocket(clientSocket); // Close the socket for Windows
#else
    close(clientSocket); // Close the socket for Unix/Linux
#endif

#ifdef _WIN32
	WSACleanup(); // Clean up Winsock for Windows
#endif

	return 0; // Return 0 to indicate successful execution
}
