/*
 ============================================================================
 Name        : header.h
 Authors     : de Dato Domenico
 Authors     : Cassano Grazia
 Version     :
 Copyright   :
 Description : Header file for Calculator with TCP protocol
 ============================================================================
 */

#ifndef HEADER_H_
#define HEADER_H_

#ifdef _WIN32
#include <winsock.h> // Include Winsock library for Windows
#else
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close // Define closesocket for Unix/Linux
#include <termios.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <conio.h> // Include conio.h for Windows

#define SERVER_ADDR "127.0.0.1" // Define the server address
#define PORT 10000 // Define the port number for communication
#define BUFFER_SIZE 1024 // Define buffer size for sending/receiving data

#endif /* HEADER_H_ */
