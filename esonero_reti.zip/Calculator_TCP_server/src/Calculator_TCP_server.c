/*
 ============================================================================
 Name        : Calculator_TCP_server.c
 Author      : de Dato Domenico
 Version     :
 Copyright   :
 Description : Calculator with TCP protocol server
 ============================================================================
 */

#include "header.h"

char buffer[BUFFER_SIZE]; // Global buffer to store data received and sent

// Function to clear the console screen
void clearScreen(){
#ifdef _WIN32
	system("cls"); // Clear screen for Windows
#else
    system("clear"); // Clear screen for Linux/Unix
#endif
}

// Function to perform addition
void add(double num1, double num2){
	double result = 0;
    result = num1 + num2;
    sprintf(buffer + strlen(buffer), "%.2f", result);
}

// Function to perform subtraction
void sub(double num1, double num2){
	double result = 0;
    result = num1 - num2;
    sprintf(buffer + strlen(buffer), "%.2f", result);
}

// Function to perform multiplication
void mult(double num1, double num2){
	double result = 0;
    result = num1 * num2;
    sprintf(buffer + strlen(buffer), "%.2f", result);
}

// Function to perform division
void division(double num1, double num2){
	double result = 0;
	if (num2 != 0) {
		result = num1 / num2;
		memset(buffer, '\0', BUFFER_SIZE);
		sprintf(buffer + strlen(buffer), "%.2f", result);
	} else {
		strcat(buffer, "\tError: Division by zero.\n");
	}
}

int main() {
    #ifdef _WIN32
    WSADATA wsaData; // Windows-specific structure to hold information about Winsock implementation
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("Error during Winsock initialization.\n");
        return 1;
    }
    #endif

    int serverSocket, clientSocket; // Server and client socket descriptors
    struct sockaddr_in serverAddr, clientAddr; // Server and client address structures
    socklen_t clientAddrSize = sizeof(clientAddr); // Size of client address structure
    int result;

    // Create a socket
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        printf("Error creating the socket.\n");
        return 1;
    }

    // Configure server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    // Bind the socket to the server address
    if (bind(serverSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr)) == -1) {
        printf("Error binding the socket.\n");
        return 1;
    }

    // Start listening for incoming connections
    listen(serverSocket, MAX_CLIENTS);

    while(1) {
        clearScreen(); // Clear the console screen

        // Accept incoming client connection
        clientSocket = accept(serverSocket, (struct sockaddr*) &clientAddr, &clientAddrSize);
        if (clientSocket == -1) {
            printf("Error accepting the connection.\n");
            return 1;
        }

        // Get the client's IP address
        char* clientIP = inet_ntoa(clientAddr.sin_addr);
        printf("Connection established with %s:%i\n", clientIP, PORT);

        while((result = recv(clientSocket, buffer, BUFFER_SIZE, 0)) > 0) {
            if (result == -1) {
                printf("Error reading data.\n");
                return 1;
            }

            double num1, num2;
            char operator;

            puts(buffer); // Print the received operation
            // Parse the received data to extract operator and operands
            if (sscanf(buffer, "%c %lf %lf", &operator, &num1, &num2) == 3) {
                memset(buffer, '\0', BUFFER_SIZE);
                // Perform the requested operation
                switch (operator) {
                    case '+':
                        add(num1, num2);
                        break;
                    case '-':
                        sub(num1, num2);
                        break;
                    case '*':
                        mult(num1, num2);
                        break;
                    case '/':
                        division(num1, num2);
                        break;
                    default:
                        strcat(buffer, "\tInvalid operator.\n");
                        break;
                }
            } else {
                strcat(buffer, "\t<--Invalid input. Please enter a valid mathematical operation (+, -, *, /).\n");
            }
            printf("The result of the operation is:\t%s\n", buffer);
            // Send the result back to the client
            send(clientSocket, buffer, strlen(buffer), 0);
            memset(buffer, '\0', BUFFER_SIZE);
        }

        // Handle client disconnection
        if(result == 0) {
            printf("Client disconnected.\n");
            closesocket(clientSocket);
        } else if(result == -1) {
            printf("Error receiving data.\n");
            return 1;
        }
    }

    // Close the server socket
    #ifdef _WIN32
    closesocket(serverSocket);
    #else
    close(serverSocket);
    #endif

    // Clean up Winsock (only on Windows)
    #ifdef _WIN32
    WSACleanup();
    #endif

    return 0;
}
